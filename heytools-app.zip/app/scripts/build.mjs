#!/usr/bin/env node
/**
 * HeyTools app builder
 * --------------------
 * Turns the website (one folder per tool, each an index.html that pulls fonts and
 * libraries from CDNs) into a self-contained, fully offline bundle in ./www.
 * That one bundle is what Android, iOS, Windows, Linux, macOS and the PWA all ship.
 *
 * Usage:  node scripts/build.mjs [--strict] [--bg-model=medium|small|none] [--src=..]
 *   --strict        exit 1 if anything could not be bundled for offline use (CI uses this)
 *   --bg-model      which AI model to bundle for Background Removal (default: medium, ~85 MB;
 *                   small ~45 MB; none = leave that tool downloading its model on first use)
 *   --src           folder that holds the tool folders (default: the repo root, i.e. "..")
 */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createRequire } from 'node:module';
import { spawnSync } from 'node:child_process';

const argv = process.argv.slice(2);
const flag = (name) => argv.find((a) => a === name || a.startsWith(name + '='));
const flagValue = (name, dflt) => { const f = flag(name); return f && f.includes('=') ? f.split('=').slice(1).join('=') : dflt; };

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SRC = path.resolve(ROOT, flagValue('--src', '..'));
const WWW = path.join(ROOT, 'www');
const NM = path.join(ROOT, 'node_modules');
const STRICT = !!flag('--strict');
const BG_MODEL = flagValue('--bg-model', 'medium');
const require = createRequire(import.meta.url);

const warnings = [];
const warn = (m) => { warnings.push(m); console.warn('  ! ' + m); };
const log = (m) => console.log(m);

// ------------------------------------------------------------------ fs helpers
const rmrf = (p) => fs.rmSync(p, { recursive: true, force: true });
const mkdirp = (p) => fs.mkdirSync(p, { recursive: true });
function copyFile(from, to) { mkdirp(path.dirname(to)); fs.copyFileSync(from, to); }
function copyTree(from, to, skip = () => false) {
  mkdirp(to);
  for (const e of fs.readdirSync(from, { withFileTypes: true })) {
    if (skip(e.name)) continue;
    const a = path.join(from, e.name), b = path.join(to, e.name);
    e.isDirectory() ? copyTree(a, b, skip) : fs.copyFileSync(a, b);
  }
}
function walk(dir, out = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    e.isDirectory() ? walk(p, out) : out.push(p);
  }
  return out;
}
const pkgPath = (name, ...rest) => path.join(NM, ...name.split('/'), ...rest);
const hasPkg = (name) => fs.existsSync(pkgPath(name, 'package.json'));
const mb = (n) => (n / 1048576).toFixed(1) + ' MB';

// ------------------------------------------------------------------ the dependency mirror
// Each entry: [folder under www/vendor, path the web pages used on that CDN, npm package, file inside the package]
// The local path mirrors the CDN path so prefix constants in the apps (e.g. CD+'jszip/...') keep working.
const MIRROR = [
  ['cdnjs', 'three.js/r128/three.min.js', 'three', 'build/three.min.js'],
  ['cdnjs', 'fabric.js/5.3.0/fabric.min.js', 'fabric', 'dist/fabric.min.js'],
  ['cdnjs', 'jsbarcode/3.11.6/JsBarcode.all.min.js', 'jsbarcode', 'dist/JsBarcode.all.min.js'],
  ['cdnjs', 'qrcode-generator/1.4.4/qrcode.min.js', 'qrcode-generator', 'qrcode.js'],
  ['cdnjs', 'jszip/3.10.1/jszip.min.js', 'jszip', 'dist/jszip.min.js'],
  ['cdnjs', 'pdf.js/3.11.174/pdf.min.js', 'pdfjs-dist', 'build/pdf.min.js'],
  ['cdnjs', 'pdf.js/3.11.174/pdf.worker.min.js', 'pdfjs-dist', 'build/pdf.worker.min.js'],
  ['cdnjs', 'jspdf/2.5.1/jspdf.umd.min.js', 'jspdf', 'dist/jspdf.umd.min.js'],
  ['cdnjs', 'jspdf-autotable/3.8.2/jspdf.plugin.autotable.min.js', 'jspdf-autotable', 'dist/jspdf.plugin.autotable.min.js'],
  ['cdnjs', 'pptxgenjs/3.12.0/pptxgen.bundle.js', 'pptxgenjs', 'dist/pptxgen.bundle.js'],
  ['cdnjs', 'xlsx/0.18.5/xlsx.full.min.js', 'xlsx', 'dist/xlsx.full.min.js'],
  ['cdnjs', 'mammoth/1.6.0/mammoth.browser.min.js', 'mammoth', 'mammoth.browser.min.js'],
  ['npm', 'three@0.128.0/examples/js/controls/OrbitControls.js', 'three', 'examples/js/controls/OrbitControls.js'],
  ['npm', 'hls.js@1/dist/hls.min.js', 'hls.js', 'dist/hls.min.js'],
  ['npm', '@ffmpeg/ffmpeg@0.12.10/dist/umd/ffmpeg.js', '@ffmpeg/ffmpeg', 'dist/umd/ffmpeg.js'],
  ['npm', '@ffmpeg/ffmpeg@0.12.10/dist/umd/814.ffmpeg.js', '@ffmpeg/ffmpeg', 'dist/umd/814.ffmpeg.js'],
  ['npm', '@ffmpeg/util@0.12.1/dist/umd/index.js', '@ffmpeg/util', 'dist/umd/index.js'],
  ['npm', '@ffmpeg/core@0.12.6/dist/umd/ffmpeg-core.js', '@ffmpeg/core', 'dist/umd/ffmpeg-core.js'],
  ['npm', '@ffmpeg/core@0.12.6/dist/umd/ffmpeg-core.wasm', '@ffmpeg/core', 'dist/umd/ffmpeg-core.wasm'],
  ['unpkg', 'lucide.min.js', 'lucide', 'dist/umd/lucide.min.js'],
];
// Earth's Zipcode textures (unpkg three-globe/example/img/*)
const GLOBE_IMAGES = ['earth-blue-marble.jpg', 'earth-topology.png', 'earth-clouds.png'];

// Font requests the launcher itself needs, written like a Google Fonts css2 query.
const LAUNCHER_FONTS = 'family=Bricolage+Grotesque:wght@500;700;800&family=Figtree:wght@400;500;600;700';

// URL prefixes in the original pages -> local folders (relative to www/apps/<id>/).
const V = '../../vendor';
const PREFIX_REWRITES = [
  ['https://cdnjs.cloudflare.com/ajax/libs/', `${V}/cdnjs/`],
  ['https://cdn.jsdelivr.net/npm/', `${V}/npm/`],
  ['https://unpkg.com/three-globe/example/img/', `${V}/three-globe/img/`],
  ['https://unpkg.com/lucide@latest', `${V}/unpkg/lucide.min.js`],
];

// ------------------------------------------------------------------ 0. clean
log('HeyTools build');
log(`  source tools : ${SRC}`);
log(`  output       : ${WWW}`);
if (!fs.existsSync(NM)) warn('node_modules not found. Run "npm install" first, otherwise nothing can be bundled for offline use.');
rmrf(WWW); mkdirp(WWW);

// ------------------------------------------------------------------ 1. catalog
const catalog = JSON.parse(fs.readFileSync(path.join(ROOT, 'apps.json'), 'utf8'));
for (const a of catalog) {
  if (!fs.existsSync(path.join(SRC, a.id, 'index.html'))) throw new Error(`Tool folder "${a.id}/index.html" not found in ${SRC}`);
}
const pkgJson = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
const buildInfo = { version: pkgJson.version, built: new Date().toISOString().slice(0, 10) };
fs.writeFileSync(path.join(WWW, 'catalog.js'),
  `window.HEY_APPS=${JSON.stringify(catalog)};\nwindow.HEY_BUILD=${JSON.stringify(buildInfo)};\n`);
log(`  tools        : ${catalog.length}`);

// ------------------------------------------------------------------ 2. launcher + web icons
copyTree(path.join(ROOT, 'launcher'), WWW);
if (fs.existsSync(path.join(ROOT, 'assets', 'web'))) copyTree(path.join(ROOT, 'assets', 'web'), path.join(WWW, 'icons'));

// ------------------------------------------------------------------ 3. fonts (from @fontsource, latin subset)
function parseFontQuery(query, into) {
  // query like  family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,700&family=Anton
  for (const part of query.split('&')) {
    if (!part.startsWith('family=')) continue;
    const spec = part.slice(7);
    const [rawName, axesSpec] = spec.split(':');
    const name = decodeURIComponent(rawName.replace(/\+/g, ' '));
    const wanted = into.get(name) ?? new Set();
    into.set(name, wanted);
    if (!axesSpec) { wanted.add('400/normal'); continue; }
    const [axesStr, tuplesStr = ''] = axesSpec.split('@');
    const axes = axesStr.split(',');
    const wi = axes.indexOf('wght'), ii = axes.indexOf('ital');
    if (!tuplesStr || wi < 0) { wanted.add('400/normal'); continue; }
    for (const tuple of tuplesStr.split(';')) {
      const vals = tuple.split(',');
      const style = ii >= 0 && vals[ii] === '1' ? 'italic' : 'normal';
      const w = vals[wi];
      if (w.includes('..')) {
        const [lo, hi] = w.split('..').map(Number);
        for (const x of [100, 200, 300, 400, 500, 600, 700, 800, 900]) if (x >= lo && x <= hi) wanted.add(`${x}/${style}`);
      } else wanted.add(`${Number(w)}/${style}`);
    }
  }
}
const fontRequests = new Map();
parseFontQuery(LAUNCHER_FONTS, fontRequests);
for (const a of catalog) {
  const html = fs.readFileSync(path.join(SRC, a.id, 'index.html'), 'utf8');
  for (const m of html.matchAll(/fonts\.googleapis\.com\/css2\?([^"'<>\s]+)/g)) parseFontQuery(m[1].replace(/&amp;/g, '&'), fontRequests);
}
const fontId = (family) => family.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
const fontDir = path.join(WWW, 'vendor', 'fonts');
mkdirp(path.join(fontDir, 'files'));
let fontCss = '/* generated by scripts/build.mjs - latin subsets from @fontsource */\n';
let fontFaces = 0, fontsMissing = [];
for (const [family, wanted] of [...fontRequests].sort()) {
  const id = fontId(family);
  const filesDir = pkgPath(`@fontsource/${id}`, 'files');
  if (!fs.existsSync(filesDir)) { fontsMissing.push(family); continue; }
  const avail = new Map(); // "400/normal" -> filename
  for (const f of fs.readdirSync(filesDir)) {
    const m = f.match(new RegExp(`^${id}-latin-(\\d+)-(normal|italic)\\.woff2$`));
    if (m) avail.set(`${Number(m[1])}/${m[2]}`, f);
  }
  if (!avail.size) { fontsMissing.push(family); continue; }
  const have = [...avail.keys()].map((k) => { const [w, s] = k.split('/'); return { w: +w, s, k }; });
  const chosen = new Set();
  for (const want of wanted) {
    const [w, s] = want.split('/');
    const pool = have.filter((h) => h.s === s);
    const best = (pool.length ? pool : have).reduce((p, c) => (Math.abs(c.w - +w) < Math.abs(p.w - +w) ? c : p));
    chosen.add(best.k);
  }
  for (const k of chosen) {
    const [w, s] = k.split('/');
    const file = avail.get(k);
    copyFile(path.join(filesDir, file), path.join(fontDir, 'files', file));
    fontCss += `@font-face{font-family:'${family}';font-style:${s};font-weight:${w};font-display:swap;src:url(files/${file}) format('woff2')}\n`;
    fontFaces++;
  }
}
fs.writeFileSync(path.join(fontDir, 'fonts.css'), fontCss);
log(`  fonts        : ${fontRequests.size} families, ${fontFaces} faces`);
if (fontsMissing.length) warn(`Fonts not found in node_modules (install @fontsource/<name>): ${fontsMissing.join(', ')}`);

// ------------------------------------------------------------------ 4. libraries
let libOk = 0;
for (const [root, rel, pkg, file] of MIRROR) {
  const from = pkgPath(pkg, file);
  if (!fs.existsSync(from)) { warn(`Library missing: ${pkg}/${file}  (needed as ${root}/${rel})`); continue; }
  copyFile(from, path.join(WWW, 'vendor', root, rel));
  libOk++;
}
for (const img of GLOBE_IMAGES) {
  const from = pkgPath('three-globe', 'example', 'img', img);
  if (!fs.existsSync(from)) { warn(`Globe texture missing: three-globe/example/img/${img}`); continue; }
  copyFile(from, path.join(WWW, 'vendor', 'three-globe', 'img', img));
}
log(`  libraries    : ${libOk}/${MIRROR.length}`);

// ------------------------------------------------------------------ 5. Background Removal (AI model + runtime)
let bgReady = false;
async function bundleBackgroundRemoval() {
  if (BG_MODEL === 'none') { log('  bg-removal   : skipped (--bg-model=none), tool will download its model on first use'); return; }
  if (!hasPkg('@imgly/background-removal') || !hasPkg('@imgly/background-removal-data')) {
    warn('Background Removal packages missing (@imgly/background-removal and @imgly/background-removal-data, both 1.5.5).'); return;
  }
  let esbuild;
  try { esbuild = await import('esbuild'); } catch { warn('esbuild is not installed, cannot bundle Background Removal.'); return; }
  const out = path.join(WWW, 'vendor', 'imgly', 'bg-removal.mjs');
  mkdirp(path.dirname(out));
  await esbuild.build({
    stdin: { contents: "export * from '@imgly/background-removal';", resolveDir: ROOT, loader: 'js' },
    bundle: true, format: 'esm', platform: 'browser', target: 'es2020', minify: true, outfile: out, logLevel: 'silent',
  });
  // model files: keep the runtime + the one model we ship
  const dist = pkgPath('@imgly/background-removal-data', 'dist');
  const dataOut = path.join(WWW, 'vendor', 'imgly-data');
  mkdirp(dataOut);
  let copied = false;
  try {
    const res = JSON.parse(fs.readFileSync(path.join(dist, 'resources.json'), 'utf8'));
    const keepModel = BG_MODEL === 'small' ? /isnet_quint8/ : /isnet_fp16/;
    const pruned = {}; const hashes = new Set();
    for (const [key, meta] of Object.entries(res)) {
      const isModel = /\/models\//.test(key);
      if (isModel && !keepModel.test(key)) continue;
      pruned[key] = meta;
      for (const c of meta.chunks ?? []) hashes.add(c.hash);
    }
    const hasModel = Object.keys(pruned).some((k) => keepModel.test(k));
    if (!hasModel || !hashes.size) throw new Error('unexpected resources.json layout');
    for (const h of hashes) copyFile(path.join(dist, h), path.join(dataOut, h));
    fs.writeFileSync(path.join(dataOut, 'resources.json'), JSON.stringify(pruned));
    copied = true;
  } catch (e) {
    warn(`Could not prune the background-removal model data (${e.message}); copying everything instead (much larger).`);
    copyTree(dist, dataOut);
    copied = true;
  }
  bgReady = copied;
  const size = walk(dataOut).reduce((n, f) => n + fs.statSync(f).size, 0);
  log(`  bg-removal   : bundled (${BG_MODEL} model, ${mb(size)})`);
}
await bundleBackgroundRemoval();

// ------------------------------------------------------------------ 6. Tailwind (Earth's Zipcode used the runtime CDN build)
function compileTailwind(id, html) {
  const cfgMatch = html.match(/<script>\s*tailwind\.config\s*=\s*(\{[\s\S]*?\})\s*<\/script>/);
  let config = {};
  if (cfgMatch) { try { config = new Function(`return (${cfgMatch[1]})`)(); } catch (e) { warn(`${id}: could not read inline tailwind.config (${e.message})`); } }
  if (!hasPkg('tailwindcss')) { warn(`${id}: tailwindcss not installed, page keeps using the online Tailwind CDN.`); return null; }
  const tmp = fs.mkdtempSync(path.join(NM, '.hey-tw-'));
  try {
    const htmlFile = path.join(tmp, 'page.html');
    fs.writeFileSync(htmlFile, html);
    const cfgFile = path.join(tmp, 'tailwind.config.cjs');
    fs.writeFileSync(cfgFile, `module.exports=${JSON.stringify({ ...config, content: [htmlFile] })};`);
    const input = path.join(tmp, 'in.css');
    fs.writeFileSync(input, '@tailwind base;@tailwind components;@tailwind utilities;');
    const output = path.join(WWW, 'vendor', 'tailwind', `${id}.css`);
    mkdirp(path.dirname(output));
    const cli = require.resolve('tailwindcss/lib/cli.js', { paths: [ROOT] });
    const r = spawnSync(process.execPath, [cli, '-c', cfgFile, '-i', input, '-o', output, '--minify'], { encoding: 'utf8' });
    if (r.status !== 0 || !fs.existsSync(output)) { warn(`${id}: Tailwind compile failed: ${(r.stderr || '').trim().split('\n').pop()}`); return null; }
    return output;
  } finally { rmrf(tmp); }
}

// ------------------------------------------------------------------ 7. tools: copy + rewrite
function rewriteApp(id, html) {
  // Background Removal: local module + local model
  if (id === 'background-removal' && bgReady) {
    html = html.replace('https://cdn.jsdelivr.net/npm/@imgly/background-removal@1.5.5/+esm', `${V}/imgly/bg-removal.mjs`);
    const model = BG_MODEL === 'small' ? ",model:'small'" : '';
    html = html.replace('removeBackground(b,{output:', `removeBackground(b,{publicPath:new URL('${V}/imgly-data/',location.href).href${model},output:`);
  }
  // Tailwind runtime CDN -> compiled stylesheet
  if (/cdn\.tailwindcss\.com/.test(html)) {
    const css = compileTailwind(id, html);
    if (css) {
      html = html.replace(/<script[^>]*cdn\.tailwindcss\.com[^>]*><\/script>\s*/g, '');
      html = html.replace(/<script>\s*tailwind\.config\s*=\s*\{[\s\S]*?\}\s*<\/script>\s*/g, '');
      html = html.replace('</head>', `<link rel="stylesheet" href="${V}/tailwind/${id}.css">\n</head>`);
    }
  }
  // CDN prefixes -> local mirror
  for (const [from, to] of PREFIX_REWRITES) html = html.split(from).join(to);
  // Google Fonts + preconnect hints -> local fonts
  html = html.replace(/<link\b[^>]*(?:fonts\.googleapis\.com|fonts\.gstatic\.com)[^>]*>\s*/gi, '');
  html = html.replace(/@import\s+url\(\s*['"]?https?:\/\/fonts\.googleapis\.com[^)]*\)\s*;?/gi, '');
  html = html.replace(/<link\b[^>]*rel=["'](?:preconnect|dns-prefetch)["'][^>]*>\s*/gi, '');
  // Local copies are served from the same origin: SRI / crossorigin on them would only cause trouble
  html = html.replace(/(<script\b[^>]*src=["']\.\.\/\.\.\/vendor[^>]*?)\s+(?:integrity|crossorigin)(?:=["'][^"']*["'])?/g, '$1');
  // Native download/share bridge + local fonts, as early as possible
  const inject = `<script src="../../native-bridge.js"></script>\n<link rel="stylesheet" href="${V}/fonts/fonts.css">`;
  html = /<head[^>]*>/i.test(html) ? html.replace(/<head[^>]*>/i, (m) => `${m}\n${inject}`) : inject + html;
  return html;
}
for (const a of catalog) {
  const from = path.join(SRC, a.id), to = path.join(WWW, 'apps', a.id);
  copyTree(from, to);
  const index = path.join(to, 'index.html');
  fs.writeFileSync(index, rewriteApp(a.id, fs.readFileSync(index, 'utf8')));
}
log(`  tools copied : ${catalog.length}`);

// ------------------------------------------------------------------ 8. service worker for the PWA build
const NO_PRECACHE = [/^vendor\/imgly-data\//, /^vendor\/npm\/@ffmpeg\/core@/]; // big: cached the first time they are used
const files = walk(WWW).map((f) => path.relative(WWW, f).split(path.sep).join('/')).filter((f) => f !== 'sw.js');
const precache = files.filter((f) => !NO_PRECACHE.some((re) => re.test(f)));
const version = crypto.createHash('sha1').update(files.map((f) => f + fs.statSync(path.join(WWW, f)).size).join('|')).digest('hex').slice(0, 10);
fs.writeFileSync(path.join(WWW, 'sw.js'), `/* generated by scripts/build.mjs */
const CACHE = 'heytools-${version}';
const PRECACHE = ${JSON.stringify(['./', ...precache])};
self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => Promise.all(PRECACHE.map((u) => c.add(u).catch(() => {})))).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  const r = e.request;
  if (r.method !== 'GET') return;
  const u = new URL(r.url);
  if (u.origin !== location.origin) return; // streams, APIs and other sites go straight to the network
  e.respondWith((async () => {
    const hit = await caches.match(r, { ignoreSearch: true });
    if (hit) return hit;
    try {
      const res = await fetch(r);
      if (res.status === 200) { const c = await caches.open(CACHE); c.put(r, res.clone()); }
      return res;
    } catch (err) {
      if (r.mode === 'navigate') { const home = await caches.match('./'); if (home) return home; }
      throw err;
    }
  })());
});
`);

// ------------------------------------------------------------------ 9. summary
const total = walk(WWW).reduce((n, f) => n + fs.statSync(f).size, 0);
log(`\nDone. www/ is ${mb(total)} (${walk(WWW).length} files), service-worker version ${version}`);
if (warnings.length) {
  console.warn(`\n${warnings.length} warning(s):`);
  warnings.forEach((w) => console.warn(' - ' + w));
  if (STRICT) { console.error('\n--strict: failing because the offline bundle is incomplete.'); process.exit(1); }
  console.warn('\nThe build finished, but the items above will still need internet. Fix them, then run npm run verify.');
}
