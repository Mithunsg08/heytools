#!/usr/bin/env node
/**
 * Adds the permissions HeyTools needs to the native projects created by "cap add android|ios".
 * Safe to run more than once. Usage: node scripts/patch-native.mjs android|ios
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const platform = process.argv[2];

function patchAndroid() {
  const file = path.join(ROOT, 'android', 'app', 'src', 'main', 'AndroidManifest.xml');
  let xml = fs.readFileSync(file, 'utf8');
  const lines = [
    '<uses-permission android:name="android.permission.INTERNET" />',
    '<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />',
    '<uses-permission android:name="android.permission.CAMERA" />',                 // Recorder, Barcode, Emulsion
    '<uses-permission android:name="android.permission.RECORD_AUDIO" />',           // Recorder
    '<uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />',
    '<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />', // Compass, Earth's Zipcode
    '<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />',
    '<uses-permission android:name="android.permission.WAKE_LOCK" />',
    '<uses-feature android:name="android.hardware.camera" android:required="false" />',
    '<uses-feature android:name="android.hardware.microphone" android:required="false" />',
    '<uses-feature android:name="android.hardware.location.gps" android:required="false" />',
    '<uses-feature android:name="android.hardware.sensor.compass" android:required="false" />',
  ];
  const missing = lines.filter((l) => !xml.includes(l.match(/android:name="([^"]+)"/)[1]));
  if (missing.length) {
    xml = xml.replace('</manifest>', '    ' + missing.join('\n    ') + '\n</manifest>');
    fs.writeFileSync(file, xml);
  }
  console.log(`Android manifest: ${missing.length} entries added`);
}

function patchIos() {
  const file = path.join(ROOT, 'ios', 'App', 'App', 'Info.plist');
  let plist = fs.readFileSync(file, 'utf8');
  const keys = {
    NSCameraUsageDescription: 'HeyTools uses the camera for the Recorder and photo tools.',
    NSMicrophoneUsageDescription: 'HeyTools uses the microphone for voice and video recording.',
    NSLocationWhenInUseUsageDescription: 'HeyTools uses your location for the Compass and postal-code tools.',
    NSMotionUsageDescription: 'HeyTools uses motion sensors so the Compass can show your heading.',
    NSPhotoLibraryAddUsageDescription: 'HeyTools can save the images and files you create to your photo library.',
    NSPhotoLibraryUsageDescription: 'HeyTools lets you pick photos and videos to edit, compress and convert.',
  };
  let added = 0;
  for (const [k, v] of Object.entries(keys)) {
    if (plist.includes(`<key>${k}</key>`)) continue;
    plist = plist.replace(/<\/dict>\s*<\/plist>\s*$/, `\t<key>${k}</key>\n\t<string>${v}</string>\n</dict>\n</plist>\n`);
    added++;
  }
  fs.writeFileSync(file, plist);
  console.log(`iOS Info.plist: ${added} entries added`);
}

if (platform === 'android') patchAndroid();
else if (platform === 'ios') patchIos();
else { console.error('Usage: node scripts/patch-native.mjs android|ios'); process.exit(1); }
