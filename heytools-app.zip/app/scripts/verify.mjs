#!/usr/bin/env node
/**
 * Offline check for ./www. Fails (exit 1) if any tool still depends on a CDN, or if a local file it points at is missing.
 * Hosts that tools legitimately call at run time (search lookups, speed test, streaming) are listed, not failed.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const WWW = path.join(ROOT, 'www');
if (!fs.existsSync(WWW)) { console.error('www/ not found. Run npm run build:web first.'); process.exit(1); }

const catalog = JSON.parse(fs.readFileSync(path.join(ROOT, 'apps.json'), 'utf8'));
const BANNED = ['fonts.googleapis.com', 'fonts.gstatic.com', 'cdnjs.cloudflare.com', 'cdn.jsdelivr.net', 'unpkg.com', 'cdn.tailwindcss.com', 'staticimgly.com'];
let errors = 0;
const fail = (m) => { errors++; console.error('  x ' + m); };

for (const a of catalog) {
  const dir = path.join(WWW, 'apps', a.id);
  const file = path.join(dir, 'index.html');
  if (!fs.existsSync(file)) { fail(`${a.id}: index.html missing`); continue; }
  const html = fs.readFileSync(file, 'utf8');

  for (const host of BANNED) if (html.includes(host)) fail(`${a.id}: still references ${host}`);

  // every relative script/stylesheet/image must exist
  for (const m of html.matchAll(/\b(?:src|href)=["']([^"'#?]+)["']/g)) {
    const ref = m[1];
    if (/^(https?:|data:|blob:|mailto:|tel:|javascript:|\/\/)/i.test(ref)) continue;
    if (!/\.(js|mjs|css|png|jpe?g|svg|webp|woff2?|wasm|json)$/i.test(ref)) continue;
    if (!fs.existsSync(path.resolve(dir, ref))) fail(`${a.id}: missing local file ${ref}`);
  }

  // what is still fetched from the network at run time (informational)
  const live = new Set();
  for (const m of html.matchAll(/https?:\/\/([a-z0-9.-]+)/gi)) {
    const h = m[1].toLowerCase();
    if (/(^|\.)(w3\.org|schema\.org|example\.com)$/.test(h) || /YOUR-|yourdomain|mithunsg08|earthszipcode|unsplash|opsreveal/i.test(h)) continue;
    live.add(h);
  }
  const note = a.offline === 'full' ? (live.size ? `  (mentions: ${[...live].join(', ')})` : '') : `  [${a.offline}] ${[...live].join(', ')}`;
  console.log(`  ${a.id.padEnd(24)} ${a.offline.padEnd(8)}${note}`);
}

for (const f of ['index.html', 'catalog.js', 'launcher.js', 'launcher.css', 'native-bridge.js', 'sw.js', 'vendor/fonts/fonts.css']) {
  if (!fs.existsSync(path.join(WWW, f))) fail(`www/${f} missing`);
}
if (errors) { console.error(`\n${errors} problem(s). The app would not be fully offline.`); process.exit(1); }
console.log('\nOK: every tool is self-contained. Only the tools marked partial/online call the internet, and only for those features.');
