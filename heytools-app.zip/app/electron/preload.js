'use strict';
const { contextBridge } = require('electron');
// Tiny, read-only surface so a tool can tell it is running in the desktop app. No Node access is exposed.
contextBridge.exposeInMainWorld('heyDesktop', { platform: process.platform });
