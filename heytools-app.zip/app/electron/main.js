'use strict';
/* HeyTools desktop shell (Windows, Linux, macOS).
 * Serves the offline bundle in ../www from a private app:// origin so camera, microphone,
 * IndexedDB, fetch(), workers and wasm all behave like a secure website, with no server and no network. */
const { app, BrowserWindow, Menu, session, shell, protocol, net, desktopCapturer, dialog } = require('electron');
const path = require('node:path');
const fs = require('node:fs');
const { pathToFileURL } = require('node:url');

const WWW = path.join(__dirname, '..', 'www');
const HOME = 'app://heytools/index.html';

protocol.registerSchemesAsPrivileged([
  { scheme: 'app', privileges: { standard: true, secure: true, supportFetchAPI: true, stream: true, corsEnabled: true } },
]);

if (!app.requestSingleInstanceLock()) { app.quit(); }

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.webmanifest': 'application/manifest+json',
  '.wasm': 'application/wasm', '.svg': 'image/svg+xml', '.woff2': 'font/woff2',
};

function registerAppProtocol() {
  protocol.handle('app', async (request) => {
    try {
      let rel = decodeURIComponent(new URL(request.url).pathname);
      if (rel.endsWith('/')) rel += 'index.html';
      const file = path.normalize(path.join(WWW, rel));
      if (file !== WWW && !file.startsWith(WWW + path.sep)) return new Response('Forbidden', { status: 403 });
      if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) return new Response('Not found', { status: 404 });
      const res = await net.fetch(pathToFileURL(file).toString());
      const type = MIME[path.extname(file).toLowerCase()];
      if (!type) return res;
      const headers = new Headers(res.headers);
      headers.set('content-type', type);
      return new Response(res.body, { status: res.status, headers });
    } catch (err) {
      return new Response(String(err), { status: 500 });
    }
  });
}

const ALLOWED_PERMISSIONS = new Set([
  'media', 'geolocation', 'fullscreen', 'clipboard-read', 'clipboard-sanitized-write', 'notifications',
  'display-capture', 'pointerLock', 'mediaKeySystem', 'speaker-selection', 'screen-wake-lock' /* harmless if unknown */,
]);
const isOurs = (url) => typeof url === 'string' && url.startsWith('app://heytools');

function setupSession() {
  const ses = session.defaultSession;
  ses.setPermissionRequestHandler((wc, permission, callback) => callback(isOurs(wc.getURL()) && ALLOWED_PERMISSIONS.has(permission)));
  ses.setPermissionCheckHandler((wc, permission, origin) => isOurs(origin) && ALLOWED_PERMISSIONS.has(permission));

  // Screen recording (Recorder tool): let the person choose a screen or window
  ses.setDisplayMediaRequestHandler(async (_request, callback) => {
    try {
      const sources = await desktopCapturer.getSources({ types: ['screen', 'window'], thumbnailSize: { width: 0, height: 0 } });
      if (!sources.length) return callback({});
      let chosen = sources[0];
      if (sources.length > 1) {
        const list = sources.slice(0, 8);
        const { response } = await dialog.showMessageBox({
          type: 'question', title: 'Record which screen?', message: 'Choose what to record',
          buttons: [...list.map((s) => s.name.slice(0, 60)), 'Cancel'], cancelId: list.length, defaultId: 0,
        });
        if (response >= list.length) return callback({});
        chosen = list[response];
      }
      callback({ video: chosen, ...(process.platform === 'win32' ? { audio: 'loopback' } : {}) });
    } catch { callback({}); }
  }, { useSystemPicker: true });
}

function buildMenu() {
  const isMac = process.platform === 'darwin';
  const template = [
    ...(isMac ? [{ role: 'appMenu' }] : []),
    { role: 'editMenu' },
    { label: 'View', submenu: [
      { label: 'All tools', accelerator: 'CmdOrCtrl+H', click: (_i, w) => w && w.loadURL(HOME) },
      { role: 'reload' }, { role: 'togglefullscreen' }, { type: 'separator' },
      { role: 'resetZoom' }, { role: 'zoomIn' }, { role: 'zoomOut' },
    ] },
    { role: 'windowMenu' },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

function createWindow() {
  const win = new BrowserWindow({
    width: 1280, height: 840, minWidth: 380, minHeight: 560,
    backgroundColor: '#14213D', title: 'HeyTools', show: false, autoHideMenuBar: true,
    icon: path.join(__dirname, '..', 'build', 'icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true, nodeIntegration: false, sandbox: true, spellcheck: false,
      autoplayPolicy: 'no-user-gesture-required',
    },
  });
  win.once('ready-to-show', () => win.show());
  win.loadURL(HOME);

  // links that leave the app open in the normal browser
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^(https?:|mailto:)/i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (event, url) => {
    if (!url.startsWith('app://')) { event.preventDefault(); if (/^https?:/i.test(url)) shell.openExternal(url); }
  });
  return win;
}

app.on('second-instance', () => {
  const [win] = BrowserWindow.getAllWindows();
  if (win) { if (win.isMinimized()) win.restore(); win.focus(); }
});

app.whenReady().then(() => {
  app.setName('HeyTools');
  registerAppProtocol();
  setupSession();
  buildMenu();
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});

app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
