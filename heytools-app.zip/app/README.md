# HeyTools app

One app that contains all 21 HeyTools tools (OpsReveal excluded) and works offline.

| Platform | Technology | Output |
|---|---|---|
| Android phones and tablets | Capacitor | `.apk` (testing) / `.aab` (Play Store) |
| iPhone and iPad | Capacitor | Xcode project, TestFlight, App Store |
| Windows | Electron | installer `.exe` and portable `.exe` |
| Linux | Electron | `.AppImage` and `.deb` |
| macOS | Electron | `.dmg` |
| Any browser (also installable) | PWA | static folder `www/` |

All of them ship the **same** offline bundle, built from your existing tool folders. Your website is not modified.

## How it works

```
heytools/                      <- your repo (unchanged)
  calculator/index.html  ...   <- the 21 tools
  app/                         <- this folder
    apps.json                  <- the list of tools shown in the app
    launcher/                  <- the home screen (search, categories, favourites, viewer)
    scripts/build.mjs          <- copies every tool into www/ and makes it offline
    www/                       <- generated bundle (what every platform ships)
```

`npm run build:web` copies each tool into `www/apps/<tool>/` and swaps every CDN dependency (Google Fonts, three.js, fabric, jsPDF, pdf.js, ffmpeg.wasm, Tailwind, the background-removal AI model, ...) for a local copy. `npm run verify` then checks that nothing still points at a CDN.

## 1. Set up (once)

Requires Node 20 or newer (22 recommended). From the repo root:

```bash
cd app
npm install
npm run build:web
npm run verify        # must end with "OK"
npm run serve         # open http://localhost:8080 and try it
```

Before publishing, edit these placeholders:
- `appId` in `capacitor.config.json` and `build.appId` in `package.json` (currently `com.heytools.app`; use a reverse-domain name you own)
- `author.email` in `package.json`

## 2. Build for each platform

**Easiest: GitHub Actions.** Copy `.github/workflows/app-build.yml` to your repo, open the Actions tab, run "Build HeyTools app". You get the Android APK and the Windows, Linux and macOS installers as downloads. Push a tag like `app-v1.0.0` to attach them to a release.

**Locally:**

```bash
# Android (needs Android Studio + JDK 21)
npm run android:init     # first time only: creates android/, adds permissions and icons
npm run android:sync     # every time after you change a tool
npm run android:open     # opens Android Studio -> Run / Build > Generate Signed Bundle

# iPhone + iPad (needs a Mac with Xcode; an Apple Developer account is needed for devices and the App Store)
npm run ios:init
npm run ios:open         # pick your Team under Signing, then Run / Archive

# Desktop
npm run desktop          # run it now
npm run desktop:win      # on Windows
npm run desktop:linux    # on Linux
npm run desktop:mac      # on a Mac
```

Smaller install: `node scripts/build.mjs --bg-model=small` bundles a ~45 MB background-removal model instead of ~85 MB. `--bg-model=none` skips it (that tool then downloads its model on first use).

## What works offline

| Tool | Offline |
|---|---|
| Recorder, Notes & To Do, Emulsion, Cyber Rush, Dice Roller, Word Counter, World Clock, Compass, Calculator Suite, Barcode & QR, Video Loop, Image Compressor, Image to PDF (all its converters), Background Removal, Scientific Calculator, Password Generator | Fully |
| Video Player | Local files yes. Live TV and streaming sites need internet |
| Music Player | Your own audio files yes. Spotify and streaming sources need internet |
| Earth's Zipcode | 3D globe yes. Place and postal-code lookups need internet (OpenStreetMap) |
| Internet Speed, Media Downloads | Need internet by nature |

The launcher shows this on every card and warns when you open an internet-dependent tool while offline.

## Adding or changing tools

- Edit a tool in its own folder as usual, then `npm run build:web` (and `android:sync` / `ios:sync`).
- New tool: add the folder, add an entry to `apps.json`, add an icon in `launcher/launcher.js` (`ICONS`). If it loads a new CDN library, add it to `MIRROR` in `scripts/build.mjs` and to `package.json`; `npm run verify` will tell you if you forget.

## Known limits

- **Screen recording** (Recorder) works on desktop only. Phone web views do not offer it. Camera and microphone recording work on phones.
- **Notes reminders**: browser notifications are not available inside the Android/iOS web views, so reminders there need a native notification plugin (`@capacitor/local-notifications`). Not included yet.
- **Downloads on phones**: files a tool creates open the system share sheet ("Save to Files", Drive, WhatsApp, ...), handled by `launcher/native-bridge.js`.
- **Earth's Zipcode** used the live Tailwind CDN, which cannot work offline, so the build compiles its CSS ahead of time. Check this tool visually once; styles built from class names assembled in JavaScript would be missed.
- iOS compass needs the person to tap "allow motion" once (iOS rule). Desktop installers are unsigned; Windows SmartScreen and macOS Gatekeeper will warn until you add code-signing.
- The tool descriptions come from your website cards ("Free online ...", "in your browser"); you may want to reword them for the app.
