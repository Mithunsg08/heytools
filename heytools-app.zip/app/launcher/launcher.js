/* HeyTools launcher: one app, many tools. Plain JS on purpose (no framework, nothing to break offline). */
(function () {
  'use strict';

  var APPS = window.HEY_APPS || [];
  var BUILD = window.HEY_BUILD || {};
  var $ = function (id) { return document.getElementById(id); };
  var Cap = window.Capacitor;
  var isNative = !!(Cap && Cap.isNativePlatform && Cap.isNativePlatform());
  var isElectron = location.protocol === 'app:';

  // ---------- tiny icon set (24x24, stroke) ----------
  var ICONS = {
    'video-player': '<rect x="3" y="5" width="18" height="14" rx="3"/><path d="M10 9.5v5l4.5-2.5z" fill="currentColor"/>',
    'music-player': '<path d="M9 18V6l10-2v12"/><circle cx="7" cy="18" r="2.5"/><circle cx="17" cy="16" r="2.5"/>',
    'recorder': '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="3.4" fill="currentColor"/>',
    'notes-to-do-list': '<rect x="4.5" y="3" width="15" height="18" rx="3"/><path d="M8.5 9l1.6 1.6 2.8-2.9M8.5 15l1.6 1.6 2.8-2.9M15 9.5h1.5M15 15.5h1.5"/>',
    'emulsion': '<rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="10" r="1.8"/><path d="M4 18l5-5 4 4 3-3 4 4"/>',
    'cyber-rush': '<path d="M13 2.5L5 13.5h6l-1 8 8-11h-6z"/>',
    'earth-zipcode': '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3.2 3.2 3.2 14.8 0 18M12 3c-3.2 3.2-3.2 14.8 0 18"/>',
    'internet-speed': '<path d="M4 17a8 8 0 1 1 16 0"/><path d="M12 17l4-5"/><circle cx="12" cy="17" r="1" fill="currentColor"/>',
    'dice-roller': '<rect x="4" y="4" width="16" height="16" rx="3.5"/><circle cx="9" cy="9" r="1.1" fill="currentColor"/><circle cx="15" cy="15" r="1.1" fill="currentColor"/><circle cx="12" cy="12" r="1.1" fill="currentColor"/>',
    'word-counter': '<path d="M4 7h16M4 12h16M4 17h8"/><path d="M16 15.5l1.5 1.5 3-3.2"/>',
    'world-clock': '<circle cx="12" cy="13" r="8"/><path d="M12 9v4l3 2M9.5 3h5"/>',
    'compass': '<circle cx="12" cy="12" r="9"/><path d="M15.8 8.2l-2.2 5.4-5.4 2.2 2.2-5.4z"/>',
    'calculator': '<rect x="5" y="3" width="14" height="18" rx="3"/><path d="M8.5 7.5h7M9 12h.01M12 12h.01M15 12h.01M9 16h.01M12 16h.01M15 16h.01" stroke-width="2.4"/>',
    'barcode-generate': '<path d="M4 6v12M7 6v12M13 6v12M16 6v12M20 6v12"/><path d="M10 6v12" stroke-width="3.2"/>',
    'video-loop': '<path d="M17 3l3 3-3 3"/><path d="M4 12V10a4 4 0 0 1 4-4h12"/><path d="M7 21l-3-3 3-3"/><path d="M20 12v2a4 4 0 0 1-4 4H4"/>',
    'image-compress': '<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/><rect x="9" y="9" width="6" height="6" rx="1.5"/>',
    'image-to-pdf-converter': '<path d="M7 3h7l5 5v13H7z"/><path d="M14 3v5h5M10 14h6M10 17.5h4"/>',
    'background-removal': '<circle cx="7.5" cy="7.5" r="3"/><circle cx="7.5" cy="16.5" r="3"/><path d="M10 9.5L20 19M10 14.5L20 5"/>',
    'scientific-calculator': '<path d="M4.5 6h6M7.5 3v6M14 6h5.5M5 16l5.5 5M10.5 16L5 21M14 16h5.5M14 20h5.5"/>',
    'media-downloads': '<path d="M12 4v11M7.5 10.5L12 15l4.5-4.5M5 20h14"/>',
    'password-generator': '<rect x="5" y="10" width="14" height="10" rx="3"/><path d="M8 10V7.5a4 4 0 0 1 8 0V10"/><circle cx="12" cy="15" r="1.3" fill="currentColor"/>'
  };
  var CAT_LABEL = { all: 'All', media: 'Media', utility: 'Utility', image: 'Image', games: 'Games' };
  var BADGE = { full: 'Works offline', partial: 'Partly offline', online: 'Needs internet' };

  // ---------- favourites ----------
  var favs = [];
  try { favs = JSON.parse(localStorage.getItem('hey.fav') || '[]'); } catch (e) { favs = []; }
  function saveFavs() { try { localStorage.setItem('hey.fav', JSON.stringify(favs)); } catch (e) { /* storage blocked: skip */ } }

  // ---------- state ----------
  var state = { q: '', cat: 'all' };

  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  function renderChips() {
    var cats = ['all'];
    APPS.forEach(function (a) { if (cats.indexOf(a.category) < 0) cats.push(a.category); });
    $('chips').innerHTML = cats.map(function (c) {
      return '<button class="chip" role="tab" data-cat="' + c + '" aria-selected="' + (state.cat === c) + '">' + esc(CAT_LABEL[c] || c) + '</button>';
    }).join('');
  }

  function matches(a) {
    if (state.cat !== 'all' && a.category !== state.cat) return false;
    var q = state.q.trim().toLowerCase();
    return !q || (a.name + ' ' + a.description + ' ' + a.category).toLowerCase().indexOf(q) >= 0;
  }

  function renderGrid() {
    var list = APPS.filter(matches);
    list.sort(function (a, b) { return (favs.indexOf(b.id) >= 0) - (favs.indexOf(a.id) >= 0); }); // stable: favourites first
    $('grid').innerHTML = list.map(function (a) {
      var isFav = favs.indexOf(a.id) >= 0;
      return '<article class="card" style="--c:var(--c-' + a.category + ')">' +
        '<div class="card-head"><span class="tile"><svg viewBox="0 0 24 24" aria-hidden="true">' + (ICONS[a.id] || '') + '</svg></span>' +
        '<div><h3><button class="open-btn" data-open="' + a.id + '">' + esc(a.name) + '</button></h3>' +
        (a.tag && a.tag !== 'Free' ? '<span class="tag">' + esc(a.tag) + '</span>' : '') + '</div></div>' +
        '<p>' + esc(a.description) + '</p>' +
        '<div class="card-foot"><span class="badge ' + a.offline + '"><i></i>' + BADGE[a.offline] + '</span><span class="open">Open ›</span></div>' +
        '<button class="fav" data-fav="' + a.id + '" aria-pressed="' + isFav + '" aria-label="' + (isFav ? 'Remove ' : 'Add ') + esc(a.name) + (isFav ? ' from' : ' to') + ' favourites">' +
        '<svg viewBox="0 0 24 24" width="20" height="20"><path d="M12 3.5l2.6 5.4 5.9.8-4.3 4.1 1 5.9L12 17l-5.2 2.7 1-5.9L3.5 9.7l5.9-.8z"/></svg></button>' +
        '</article>';
    }).join('');
    $('empty').hidden = list.length > 0;
  }

  // ---------- network pill ----------
  function renderNet() {
    var on = navigator.onLine !== false;
    $('net').classList.toggle('off', !on);
    $('net').lastElementChild.textContent = on ? 'Online' : 'Offline';
  }

  // ---------- toast ----------
  var toastTimer;
  function toast(msg) {
    var t = $('toast'); t.textContent = msg; t.classList.add('show');
    clearTimeout(toastTimer); toastTimer = setTimeout(function () { t.classList.remove('show'); }, 2600);
  }
  window.heyToast = toast;

  // ---------- viewer ----------
  var current = null, frame = null;
  var FRAME_ALLOW = 'camera; microphone; geolocation; display-capture; fullscreen; autoplay; clipboard-read; clipboard-write; ' +
    'accelerometer; gyroscope; magnetometer; picture-in-picture; screen-wake-lock; web-share; encrypted-media; storage-access';

  function byId(id) { for (var i = 0; i < APPS.length; i++) if (APPS[i].id === id) return APPS[i]; return null; }

  function showNotice(app) {
    var off = navigator.onLine === false, msg = '';
    if (app.offline === 'online') msg = off ? app.name + ' needs an internet connection and you are offline right now.' : '';
    else if (app.offline === 'partial' && off) msg = 'You are offline. ' + (app.offlineNote || 'Some features need internet.');
    $('vnotice-text').textContent = msg;
    $('vnotice').hidden = !msg;
  }

  function mountFrame(app) {
    if (frame) { frame.remove(); frame = null; }
    $('spin').classList.remove('done');
    frame = document.createElement('iframe');         // a fresh element each time keeps browser history clean
    frame.title = app.name;
    frame.setAttribute('allow', FRAME_ALLOW);
    frame.setAttribute('allowfullscreen', '');
    frame.addEventListener('load', function () { $('spin').classList.add('done'); });
    frame.src = 'apps/' + app.id + '/index.html';
    $('vstage').appendChild(frame);
  }

  function showViewer(app) {
    current = app;
    $('vtitle').textContent = app.name;
    document.title = app.name + ' · HeyTools';
    $('home').hidden = true; $('viewer').hidden = false;
    showNotice(app); mountFrame(app);
  }
  function showHome() {
    if (frame) { frame.remove(); frame = null; }   // stops audio / camera / 3D loops
    current = null;
    $('viewer').hidden = true; $('home').hidden = false;
    document.title = 'HeyTools';
  }

  function openApp(id) {
    var app = byId(id); if (!app) return;
    history.pushState({ app: id }, '', '#/a/' + id);
    showViewer(app);
  }
  function closeApp() {
    if (!current) return;
    history.replaceState(null, '', '#/');
    showHome();
  }
  function route() {
    var m = /^#\/a\/([\w-]+)/.exec(location.hash), app = m && byId(m[1]);
    if (app) { if (!current || current.id !== app.id) showViewer(app); } else if (current) showHome();
  }

  // ---------- events ----------
  document.addEventListener('click', function (e) {
    var t = e.target.closest ? e.target.closest('[data-open],[data-fav],[data-cat]') : null;
    if (!t) return;
    if (t.dataset.open) { openApp(t.dataset.open); return; }
    if (t.dataset.fav) {
      var id = t.dataset.fav, i = favs.indexOf(id);
      if (i >= 0) favs.splice(i, 1); else favs.push(id);
      saveFavs(); renderGrid();
      var again = document.querySelector('[data-fav="' + id + '"]'); if (again) again.focus();
      return;
    }
    if (t.dataset.cat) { state.cat = t.dataset.cat; renderChips(); renderGrid(); }
  });
  $('q').addEventListener('input', function (e) { state.q = e.target.value; renderGrid(); });
  $('back').addEventListener('click', closeApp);
  $('reload').addEventListener('click', function () { if (current) { showNotice(current); mountFrame(current); } });
  $('vnotice-x').addEventListener('click', function () { $('vnotice').hidden = true; });
  window.addEventListener('popstate', route);
  window.addEventListener('online', function () { renderNet(); if (current) showNotice(current); toast('Back online'); });
  window.addEventListener('offline', function () { renderNet(); if (current) showNotice(current); toast('You are offline. Most tools still work.'); });
  document.addEventListener('keydown', function (e) {
    var typing = /^(INPUT|TEXTAREA)$/.test((document.activeElement || {}).tagName || '');
    if (e.key === '/' && !typing && !current) { e.preventDefault(); $('q').focus(); }
  });

  // fullscreen (desktop browsers / Electron only)
  if (document.fullscreenEnabled && !isNative) {
    $('full').hidden = false;
    $('full').addEventListener('click', function () {
      if (document.fullscreenElement) document.exitFullscreen(); else $('viewer').requestFullscreen().catch(function () {});
    });
  }

  // Android hardware back button: close the tool first, exit only from the home screen
  if (isNative && Cap.Plugins && Cap.Plugins.App && Cap.Plugins.App.addListener) {
    Cap.Plugins.App.addListener('backButton', function () {
      if (current) closeApp(); else Cap.Plugins.App.exitApp();
    });
  }

  // PWA: offline cache + install button (web only; the native apps already ship every file)
  if (!isNative && !isElectron && 'serviceWorker' in navigator && /^https?:$/.test(location.protocol)) {
    navigator.serviceWorker.register('sw.js').catch(function () {});
    var deferred;
    window.addEventListener('beforeinstallprompt', function (e) { e.preventDefault(); deferred = e; $('install').hidden = false; });
    $('install').addEventListener('click', function () {
      if (!deferred) return; deferred.prompt(); deferred.userChoice.finally(function () { deferred = null; $('install').hidden = true; });
    });
  }

  // ---------- go ----------
  $('build').textContent = 'HeyTools ' + (BUILD.version || '') + (BUILD.built ? ' · built ' + BUILD.built : '');
  renderChips(); renderGrid(); renderNet(); route();
})();
