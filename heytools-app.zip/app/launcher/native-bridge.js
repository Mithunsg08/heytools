/* HeyTools native bridge: injected into every tool page by scripts/build.mjs.
 *
 * Android and iOS web views ignore <a download> for blob: files and have no navigator.share on
 * Android. Most HeyTools tools export files that way (compressed images, PDFs, barcodes, recordings,
 * passwords...). Inside the Capacitor apps this script sends those files to the native share sheet
 * ("Save to Files", "Save to Drive", WhatsApp, ...). On desktop and in the browser it does nothing,
 * because there the browser/Electron already saves downloads properly.
 */
(function () {
  'use strict';
  var C;
  try { C = window.Capacitor || (window.parent && window.parent.Capacitor); } catch (e) { /* cross-origin parent */ }
  if (!C || !C.isNativePlatform || !C.isNativePlatform()) return;
  var P = C.Plugins || {};
  if (!P.Filesystem || !P.Share) return;

  function toast(msg) { try { (window.parent && window.parent.heyToast) ? window.parent.heyToast(msg) : alert(msg); } catch (e) { /* ignore */ } }
  function safeName(n) { return String(n || 'download').replace(/[\\/:*?"<>|]+/g, '_').slice(0, 120) || 'download'; }

  function blobToBase64(blob) {
    return new Promise(function (resolve, reject) {
      var r = new FileReader();
      r.onload = function () { resolve(String(r.result).split(',')[1] || ''); };
      r.onerror = function () { reject(r.error || new Error('read failed')); };
      r.readAsDataURL(blob);
    });
  }

  function shareBlob(blob, name) {
    name = safeName(name);
    return blobToBase64(blob).then(function (data) {
      return P.Filesystem.writeFile({ path: 'hey-share/' + name, data: data, directory: 'CACHE', recursive: true });
    }).then(function (res) {
      return P.Share.share({ title: name, url: res.uri, dialogTitle: 'Save or share ' + name });
    }).catch(function (err) {
      var msg = String((err && err.message) || err || '');
      if (/cancel|dismiss/i.test(msg)) return;           // user closed the share sheet
      toast('Could not save the file: ' + msg);
    });
  }

  function saveFromUrl(href, name) {
    return fetch(href).then(function (r) { return r.blob(); }).then(function (b) { return shareBlob(b, name); });
  }

  function isLocalDownload(a) {
    return a && a.hasAttribute && a.hasAttribute('download') && /^(blob:|data:)/.test(a.href || '');
  }

  // 1) clicks on <a download href="blob:..."> that are in the page
  document.addEventListener('click', function (e) {
    var a = e.target && e.target.closest ? e.target.closest('a[download]') : null;
    if (!isLocalDownload(a)) return;
    e.preventDefault(); e.stopPropagation();
    saveFromUrl(a.href, a.getAttribute('download') || 'download');
  }, true);

  // 2) programmatic a.click() on anchors that were never added to the page
  var nativeClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    if (isLocalDownload(this)) { saveFromUrl(this.href, this.getAttribute('download') || 'download'); return; }
    return nativeClick.apply(this, arguments);
  };

  // 3) navigator.share where the web view lacks it (Android)
  if (!navigator.share) {
    navigator.canShare = function () { return true; };
    navigator.share = function (d) {
      d = d || {};
      if (d.files && d.files.length) return shareBlob(d.files[0], d.files[0].name);
      return P.Share.share({ title: d.title, text: d.text, url: d.url, dialogTitle: d.title });
    };
  }
})();
